# Monthly Expenses Calculator

A simple, fast, and responsive Monthly Expenses Calculator and Budget Tracker built with React, Vite, Tailwind CSS, and PWA (Android WebAPK installable).

## Features
- **Monthly Income & Balance Tracking**: Calculate total expenses, remaining balance, and savings rate.
- **Preloaded Sample Data**: Includes sample expenses and a 1-click restore button.
- **Category Breakdown**: Visual progress bars showing where your money goes.
- **Multi-Currency**: Switch easily between `$ (USD)`, `₹ (INR)`, `€ (EUR)`, and `£ (GBP)`.
- **Offline & Local Storage**: Data automatically persists in the browser.
- **Android APK / PWA Ready**: Installable directly on Android devices as a native WebAPK.

## Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or bun

### Installation
```bash
git clone https://github.com/your-username/monthly-expenses-calculator.git
cd monthly-expenses-calculator
npm install
```

### Running Locally
```bash
npm run dev
```
Open your browser at `http://localhost:3000` (or the URL printed in the terminal).

### Building for Production
```bash
npm run build
```

## Android APK & Mobile Installation
1. Open the hosted web application URL in **Google Chrome** on your Android smartphone.
2. Tap the three dots menu (**⋮**) in the top right.
3. Select **"Install app"** or **"Add to Home screen"**.
4. Android will automatically package it as a native **WebAPK** onto your device home screen and app drawer.

## License
MIT
