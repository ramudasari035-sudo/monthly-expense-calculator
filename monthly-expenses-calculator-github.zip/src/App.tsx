import React, { useEffect, useState } from 'react';
import {
  Download,
  Plus,
  RefreshCw,
  Smartphone,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';

interface Expense {
  id: string;
  title: string;
  amount: number;
  category: string;
  date: string;
}

const CATEGORIES = [
  'Rent & Housing',
  'Groceries & Food',
  'Utilities & Bills',
  'Transportation',
  'Dining & Snacks',
  'Health & Care',
  'Subscriptions',
  'Other',
];

const INITIAL_EXPENSES: Expense[] = [
  { id: '1', title: 'Monthly Apartment Rent', amount: 1200, category: 'Rent & Housing', date: '2026-09-01' },
  { id: '2', title: 'Supermarket Groceries', amount: 350, category: 'Groceries & Food', date: '2026-09-03' },
  { id: '3', title: 'Electricity & Gas Bill', amount: 115, category: 'Utilities & Bills', date: '2026-09-05' },
  { id: '4', title: 'High-Speed Wi-Fi Internet', amount: 60, category: 'Utilities & Bills', date: '2026-09-07' },
  { id: '5', title: 'Fuel & Metro Transit', amount: 140, category: 'Transportation', date: '2026-09-10' },
  { id: '6', title: 'Weekend Dining & Cafe', amount: 85, category: 'Dining & Snacks', date: '2026-09-12' },
  { id: '7', title: 'Netflix & Spotify Family', amount: 30, category: 'Subscriptions', date: '2026-09-15' },
];

export default function App() {
  const [currency, setCurrency] = useState('$');
  const [monthlyIncome, setMonthlyIncome] = useState<number>(3500);
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('simple_expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [showApkGuide, setShowApkGuide] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Save expenses to localStorage
  useEffect(() => {
    localStorage.setItem('simple_expenses', JSON.stringify(expenses));
  }, [expenses]);

  // Listen for PWA install prompt
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
  const balance = monthlyIncome - totalExpenses;
  const savingsRate = monthlyIncome > 0 ? Math.max(0, (balance / monthlyIncome) * 100) : 0;

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!title.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;

    const newExpense: Expense = {
      id: Date.now().toString(),
      title: title.trim(),
      amount: parsedAmount,
      category,
      date: new Date().toISOString().split('T')[0],
    };

    setExpenses([newExpense, ...expenses]);
    setTitle('');
    setAmount('');
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter((item) => item.id !== id));
  };

  const handleResetData = () => {
    if (window.confirm('Reset back to sample monthly expense data?')) {
      setExpenses(INITIAL_EXPENSES);
      setMonthlyIncome(3500);
    }
  };

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      setShowApkGuide(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 font-sans">
      <div className="max-w-2xl mx-auto space-y-5">
        
        {/* Simple Top Bar */}
        <header className="flex items-center justify-between pb-3 border-b border-slate-800 gap-2">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-100">Monthly Expenses Calculator</h1>
              <p className="text-xs text-slate-400">Simple Budget & Expense Tracker</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Currency selector */}
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 cursor-pointer"
            >
              <option value="$">$ (USD)</option>
              <option value="₹">₹ (INR)</option>
              <option value="€">€ (EUR)</option>
              <option value="£">£ (GBP)</option>
            </select>

            {/* Download GitHub ZIP Button */}
            <a
              href="/monthly-expenses-calculator-github.zip"
              download="monthly-expenses-calculator-github.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              title="Download source code ZIP for GitHub"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">GitHub</span>
              <span>.ZIP</span>
            </a>

            {/* Android APK Button */}
            <button
              onClick={handleInstallApp}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android App</span>
            </button>
          </div>
        </header>

        {/* Financial Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          
          {/* Monthly Income Card */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            <span className="text-[11px] text-slate-400 block">Monthly Income</span>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-slate-400 font-mono text-sm">{currency}</span>
              <input
                type="number"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full bg-transparent font-bold font-mono text-lg text-emerald-400 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Total Expenses Card */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            <span className="text-[11px] text-slate-400 block">Total Expenses</span>
            <span className="text-lg font-bold font-mono text-rose-400 mt-1 block">
              {currency}{totalExpenses.toLocaleString()}
            </span>
          </div>

          {/* Remaining Balance Card */}
          <div className="col-span-2 sm:col-span-1 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            <span className="text-[11px] text-slate-400 block">Remaining Balance</span>
            <span
              className={`text-lg font-bold font-mono mt-1 block ${
                balance >= 0 ? 'text-teal-400' : 'text-rose-400'
              }`}
            >
              {currency}{balance.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 block">
              Savings: {savingsRate.toFixed(0)}%
            </span>
          </div>

        </div>

        {/* Add Expense Form */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
            Add Expense
          </h2>

          <form onSubmit={handleAddExpense} className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
            <input
              type="text"
              required
              placeholder="Expense title (e.g. Grocery bill)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="sm:col-span-5 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-emerald-500"
            />

            <input
              type="number"
              step="any"
              required
              placeholder={`Amount (${currency})`}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="sm:col-span-3 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono focus:outline-hidden focus:border-emerald-500"
            />

            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="sm:col-span-3 px-2.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            <button
              type="submit"
              className="sm:col-span-1 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center justify-center transition cursor-pointer"
              title="Add"
            >
              <Plus className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Expenses List */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Expense Records ({expenses.length})
            </h2>
            <button
              onClick={handleResetData}
              className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 transition cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Sample Data</span>
            </button>
          </div>

          <div className="divide-y divide-slate-800/80">
            {expenses.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No expenses added yet.</p>
            ) : (
              expenses.map((item) => (
                <div
                  key={item.id}
                  className="py-2.5 flex items-center justify-between text-xs hover:bg-slate-850/40 px-1 rounded transition"
                >
                  <div>
                    <span className="font-medium text-slate-200 block">{item.title}</span>
                    <span className="text-[11px] text-slate-400">{item.category} · {item.date}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-slate-100">
                      -{currency}{item.amount.toLocaleString()}
                    </span>
                    <button
                      onClick={() => handleDeleteExpense(item.id)}
                      className="text-slate-500 hover:text-rose-400 transition cursor-pointer p-1"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Spending by Category
          </h2>

          <div className="space-y-2">
            {CATEGORIES.map((cat) => {
              const catTotal = expenses
                .filter((e) => e.category === cat)
                .reduce((sum, item) => sum + item.amount, 0);
              if (catTotal === 0) return null;
              const percent = totalExpenses > 0 ? (catTotal / totalExpenses) * 100 : 0;

              return (
                <div key={cat} className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span>{cat}</span>
                    <span className="font-mono">{currency}{catTotal.toLocaleString()} ({percent.toFixed(0)}%)</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Simple Android APK Install Modal */}
      {showApkGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="w-full max-w-md p-5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-100 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-sm text-slate-100">Install as Android APK App</h3>
              </div>
              <button
                onClick={() => setShowApkGuide(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-300 leading-relaxed">
              You can install this app directly onto your Android device as a standalone native app (WebAPK):
            </p>

            <ol className="list-decimal list-inside space-y-2 text-slate-400 bg-slate-950 p-3 rounded-lg border border-slate-850">
              <li>Open this page on your Android phone in <strong>Google Chrome</strong>.</li>
              <li>Tap the <strong>three dots menu (⋮)</strong> at top right.</li>
              <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
              <li>Android automatically generates the native app package and places the app icon on your home screen.</li>
            </ol>

            <button
              onClick={() => setShowApkGuide(false)}
              className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition"
            >
              Got it
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
