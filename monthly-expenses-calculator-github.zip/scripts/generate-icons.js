import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createCRC32Table() {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
}

const crcTable = createCRC32Table();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(12 + len);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const typeAndData = buf.subarray(4, 8 + len);
  const crc = crc32(typeAndData);
  buf.writeUInt32BE(crc, 8 + len);
  return buf;
}

function generatePng(width, height, isMaskable = false) {
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  const cx = width / 2;
  const cy = height / 2;
  const radius = width * (isMaskable ? 0.38 : 0.45);
  const cornerRadius = width * 0.22;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;

      // Rounded rect background distance
      const dx = Math.max(Math.abs(x - cx) - (cx - cornerRadius), 0);
      const dy = Math.max(Math.abs(y - cy) - (cy - cornerRadius), 0);
      const distToCorner = Math.hypot(dx, dy);

      let r = 16;
      let g = 185;
      let b = 129; // emerald-500
      let a = 255;

      // Background gradient: slate-900 to emerald-900 / teal
      const t = (x + y) / (width + height);
      r = Math.round(15 + t * 15);
      g = Math.round(23 + t * 45);
      b = Math.round(42 + t * 30);

      // Card / calculator icon in center
      const inIconBox = (
        Math.abs(x - cx) < width * 0.28 &&
        Math.abs(y - cy) < height * 0.32
      );

      if (inIconBox) {
        // Calculator body
        const isHeader = (y < cy - height * 0.12 && y > cy - height * 0.26);
        const inDisplay = isHeader && (Math.abs(x - cx) < width * 0.22);

        if (inDisplay) {
          // Display screen (mint neon)
          r = 16;
          g = 185;
          b = 129;
        } else {
          // Keys grid
          const isButtonArea = y > cy - height * 0.08 && y < cy + height * 0.26;
          if (isButtonArea) {
            const bx = Math.floor((x - (cx - width * 0.22)) / (width * 0.11));
            const by = Math.floor((y - (cy - height * 0.06)) / (height * 0.1));
            const onButton = (bx >= 0 && bx < 4 && by >= 0 && by < 3);
            const insideBtn = onButton && (
              ((x - (cx - width * 0.22)) % (width * 0.11)) > 3 &&
              ((y - (cy - height * 0.06)) % (height * 0.1)) > 3
            );

            if (insideBtn) {
              if (bx === 3) {
                // Accent equals / operator key (amber / emerald)
                r = 245;
                g = 158;
                b = 11;
              } else {
                r = 71;
                g = 85;
                b = 105;
              }
            } else {
              r = 30;
              g = 41;
              b = 59;
            }
          } else {
            r = 30;
            g = 41;
            b = 59;
          }
        }
      }

      // If outside rounded corner (not maskable)
      if (!isMaskable && distToCorner > cornerRadius) {
        a = 0;
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth
  ihdr[9] = 6; // Color type (RGBA)
  ihdr[10] = 0; // Compression
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace
  const ihdrChunk = makeChunk('IHDR', ihdr);

  // IDAT chunk
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressed);

  // IEND chunk
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate PWA icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generatePng(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generatePng(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generatePng(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generatePng(180, 180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), generatePng(64, 64, false));

console.log('Generated PNG icons successfully.');
